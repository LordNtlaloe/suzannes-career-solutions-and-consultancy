import { redirect } from "next/navigation";
import { getStepAccessContext } from "@/lib/step/permissions";
import { isStaff } from "@/lib/step/access-rules";
import {
    countApplicationsForReview,
    listApplicationsForReview,
} from "@/db/queries/step/applications";
import { listCycles } from "@/db/queries/step/cycles";
import { stepPageMetadata } from "@/lib/step/metadata";
import { ApplicationsBrowser } from "@/components/step/applications-browser";

export async function generateMetadata() {
    return stepPageMetadata({
        path: "/admin/applications",
        title: "STEP Applications",
        description: "Review and manage STEP applications.",
    });
}

type SearchParams = Promise<{ page?: string; status?: string; cycle?: string }>;

export default async function StepAdminApplicationsPage({
    searchParams,
}: {
    searchParams: SearchParams;
}) {
    const sp = await searchParams;
    const page = Math.max(1, parseInt(sp.page ?? "1", 10) || 1);
    const pageSize = 20;
    const status = sp.status ?? "all";

    const { user, context } = await getStepAccessContext();
    if (!user || !isStaff(context)) redirect("/step");

    // Authorised cycle scope: global staff see everything; scoped staff see
    // only their cycles.
    const scopedCycleIds = context.staffAssignments
        .filter((a) => a.cycle_id !== null)
        .map((a) => a.cycle_id as string);
    const hasGlobal = context.staffAssignments.some((a) => a.cycle_id === null);

    const allCycles = await listCycles();
    const visibleCycles = hasGlobal ? allCycles : allCycles.filter((c) => scopedCycleIds.includes(c.id));

    let cycleId: string | null = null;
    if (hasGlobal && sp.cycle && sp.cycle !== "all") {
        cycleId = sp.cycle;
    } else if (!hasGlobal && sp.cycle && scopedCycleIds.includes(sp.cycle)) {
        cycleId = sp.cycle;
    } else if (!hasGlobal && scopedCycleIds.length > 0) {
        cycleId = scopedCycleIds[0];
    }

    const [applications, total] = await Promise.all([
        listApplicationsForReview({
            status: status === "all" ? undefined : status,
            cycleId,
            cohortId: null,
            limit: pageSize,
            offset: (page - 1) * pageSize,
        }),
        countApplicationsForReview({
            status: status === "all" ? undefined : status,
            cycleId,
            cohortId: null,
        }),
    ]);

    return (
        <div className="flex flex-col gap-4">
            <h2 className="text-[15px] font-semibold">Applications</h2>
            <ApplicationsBrowser
                applications={applications}
                total={total}
                page={page}
                pageSize={pageSize}
                status={status}
                cycleId={cycleId ?? "all"}
                cycles={visibleCycles}
            />
        </div>
    );
}
