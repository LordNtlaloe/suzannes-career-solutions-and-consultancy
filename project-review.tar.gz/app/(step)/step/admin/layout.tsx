import Link from "next/link";
import { redirect } from "next/navigation";
import { headers } from "next/headers";
import { getStepAccessContext } from "@/lib/step/permissions";
import { isStaff } from "@/lib/step/access-rules";
import { stepPath } from "@/lib/step/config";
import { stepPageMetadata } from "@/lib/step/metadata";

export async function generateMetadata() {
    return stepPageMetadata({
        path: "/admin",
        title: "STEP Admin",
        description: "Programme administration for STEP.",
    });
}

export default async function StepAdminLayout({
    children,
}: {
    children: React.ReactNode;
}) {
    const headersList = await headers();
    const host = headersList.get("host") ?? "";
    const link = (p: string) => stepPath(host, p);

    const { user, context } = await getStepAccessContext();

    if (!user) {
        redirect(
            `/sign-in?callbackUrl=${encodeURIComponent(link("/admin"))}`,
        );
    }

    // STEP permissions are scoped and independent of blog roles.
    if (!isStaff(context)) {
        redirect(link("/"));
    }

    return (
        <section className="container-x py-10 sm:py-14">
            <div className="flex flex-wrap items-center gap-3 border-b border-line pb-4">
                <h1 className="text-[16px] font-semibold">Programme administration</h1>
                <nav className="ml-auto flex items-center gap-4 text-[12px]">
                    <Link
                        href={link("/admin/applications")}
                        className="font-semibold text-blue-dark transition-opacity hover:opacity-70"
                    >
                        Applications
                    </Link>
                    <Link
                        href={link("/admin/evidence")}
                        className="font-semibold text-blue-dark transition-opacity hover:opacity-70"
                    >
                        Evidence
                    </Link>
                    <Link
                        href={link("/admin/progression")}
                        className="font-semibold text-blue-dark transition-opacity hover:opacity-70"
                    >
                        Progression
                    </Link>
                    <Link
                        href={link("/")}
                        className="text-brand-muted transition-colors hover:text-brand"
                    >
                        View site
                    </Link>
                </nav>
            </div>
            <div className="pt-6">{children}</div>
        </section>
    );
}
