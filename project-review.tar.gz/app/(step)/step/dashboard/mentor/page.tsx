import Link from "next/link";
import { redirect } from "next/navigation";
import { headers } from "next/headers";
import { getStepAccessContext } from "@/lib/step/permissions";
import { isMentor } from "@/lib/step/access-rules";
import { mentorDashboard } from "@/db/queries/step/dashboards";
import { levelLabel, pathwayLabel } from "@/lib/step/constants";
import { stepPath } from "@/lib/step/config";
import { stepPageMetadata } from "@/lib/step/metadata";

export async function generateMetadata() {
    return stepPageMetadata({
        path: "/dashboard/mentor",
        title: "Mentor Dashboard",
        description: "Your assigned participants and sessions.",
    });
}

export default async function MentorDashboardPage() {
    const headersList = await headers();
    const host = headersList.get("host") ?? "";
    const link = (p: string) => stepPath(host, p);

    const { user, context } = await getStepAccessContext();
    if (!user) redirect(`/sign-in?callbackUrl=${encodeURIComponent(link("/dashboard/mentor"))}`);
    if (!isMentor(context)) redirect(link("/dashboard"));

    const data = await mentorDashboard(user.id);

    return (
        <section className="container-x py-10 sm:py-14">
            <div className="mx-auto max-w-3xl">
                <header className="mb-8 flex flex-col gap-3">
                    <span className="text-[11px] font-semibold uppercase tracking-[2.4px] text-blue">
                        Mentor
                    </span>
                    <h1 className="section-heading">Your mentees.</h1>
                </header>

                <div className="flex flex-col gap-6">
                    <div>
                        <h2 className="mb-3 text-[12px] font-semibold uppercase tracking-[1.2px] text-brand-muted">
                            Assigned participants ({data.assigned.length})
                        </h2>
                        <div className="flex flex-col gap-3">
                            {data.assigned.map((a) => (
                                <div
                                    key={String(a.id)}
                                    className="flex flex-wrap items-center gap-x-4 gap-y-1 rounded-md border border-line bg-white px-4 py-3"
                                >
                                    <p className="text-[14px] font-semibold">
                                        {String(a.participant_name)}
                                    </p>
                                    <span className="text-[12px] text-brand-muted">
                                        {String(a.cycle_name)} · {String(a.cohort_name ?? "No cohort")}
                                    </span>
                                    <span className="ml-auto text-[12px] font-semibold text-blue-dark">
                                        {levelLabel(String(a.level))} · {pathwayLabel(String(a.pathway))}
                                    </span>
                                </div>
                            ))}
                            {data.assigned.length === 0 && (
                                <p className="section-copy">No assigned participants.</p>
                            )}
                        </div>
                    </div>

                    <div>
                        <h2 className="mb-3 text-[12px] font-semibold uppercase tracking-[1.2px] text-brand-muted">
                            Upcoming sessions ({data.sessions.length})
                        </h2>
                        <div className="flex flex-col gap-3">
                            {data.sessions.map((s) => (
                                <Link
                                    key={String(s.id)}
                                    href={link(`/dashboard/mentor/sessions/${s.id}`)}
                                    className="flex items-center justify-between rounded-md border border-line bg-white px-4 py-3 transition-colors hover:border-blue/40"
                                >
                                    <p className="text-[14px] font-semibold">{String(s.title)}</p>
                                    {s.scheduled_at ? (
                                        <span className="text-[12px] text-brand-muted">
                                            {new Date(Number(s.scheduled_at) * 1000).toLocaleString()}
                                        </span>
                                    ) : null}
                                </Link>
                            ))}
                            {data.sessions.length === 0 && (
                                <p className="section-copy">No upcoming sessions.</p>
                            )}
                        </div>
                    </div>

                    <div>
                        <h2 className="mb-3 text-[12px] font-semibold uppercase tracking-[1.2px] text-brand-muted">
                            Development actions ({data.actions.length})
                        </h2>
                        <div className="flex flex-col gap-2">
                            {data.actions.map((a) => (
                                <div
                                    key={String(a.id)}
                                    className="flex items-center justify-between rounded-md border border-line bg-light/60 px-4 py-2.5"
                                >
                                    <p className="text-[13px] font-semibold">{String(a.title)}</p>
                                    <span className="text-[12px] text-brand-muted">
                                        {String(a.status)}
                                    </span>
                                </div>
                            ))}
                            {data.actions.length === 0 && (
                                <p className="section-copy">No open development actions.</p>
                            )}
                        </div>
                    </div>
                </div>
            </div>
        </section>
    );
}
