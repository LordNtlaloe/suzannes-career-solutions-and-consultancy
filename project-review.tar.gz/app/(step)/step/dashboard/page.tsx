import Link from "next/link";
import { redirect } from "next/navigation";
import { headers } from "next/headers";
import { getStepAccessContext } from "@/lib/step/permissions";
import {
    hasAnyStepRole,
    isMentor,
    isParticipant,
    isProgrammeAdmin,
    isStaff,
} from "@/lib/step/access-rules";
import { getLatestApplicationByUser } from "@/db/queries/step/applications";
import { applicationStatusLabel } from "@/lib/step/constants";
import { stepPath } from "@/lib/step/config";
import { stepPageMetadata } from "@/lib/step/metadata";

export async function generateMetadata() {
    return stepPageMetadata({
        path: "/dashboard",
        title: "STEP Dashboard",
        description: "Your STEP programme workspace.",
    });
}

export default async function StepDashboardEntry() {
    const headersList = await headers();
    const host = headersList.get("host") ?? "";
    const link = (p: string) => stepPath(host, p);

    const { user, context } = await getStepAccessContext();

    if (!user) {
        redirect(`/sign-in?callbackUrl=${encodeURIComponent(link("/dashboard"))}`);
    }

    // No STEP responsibility: show application status or an entry point.
    if (!hasAnyStepRole(context)) {
        const application = await getLatestApplicationByUser(user.id);
        return (
            <section className="container-x py-14 sm:py-20">
                <div className="mx-auto max-w-2xl rounded-lg border border-line bg-light/60 p-8 text-center">
                    <h1 className="section-heading">Your STEP application.</h1>
                    {application ? (
                        <p className="section-copy mt-3">
                            Status: {applicationStatusLabel(application.status)}
                        </p>
                    ) : (
                        <p className="section-copy mt-3">
                            You haven&rsquo;t applied to STEP yet.
                        </p>
                    )}
                    <Link href={link("/apply")} className="btn-brand mt-6 inline-flex">
                        {application ? "Review application" : "Apply now"}
                    </Link>
                </div>
            </section>
        );
    }

    const roles = [
        isParticipant(context) ? { key: "participant", label: "Participant" } : null,
        isStaff(context) ? { key: "staff", label: "Staff" } : null,
        isMentor(context) ? { key: "mentor", label: "Mentor" } : null,
        isProgrammeAdmin(context) ? { key: "admin", label: "Programme admin" } : null,
    ].filter(Boolean) as { key: string; label: string }[];

    // Single responsibility → go straight to its view.
    if (roles.length === 1) {
        redirect(link(`/dashboard/${roles[0].key}`));
    }

    return (
        <section className="container-x py-14 sm:py-20">
            <div className="mx-auto max-w-2xl">
                <header className="mb-8 flex flex-col gap-3">
                    <span className="text-[11px] font-semibold uppercase tracking-[2.4px] text-blue">
                        Dashboard
                    </span>
                    <h1 className="section-heading">Choose a workspace.</h1>
                    <p className="section-copy">
                        You hold several STEP responsibilities. Pick the view you want.
                    </p>
                </header>

                <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                    {roles.map((role) => (
                        <Link
                            key={role.key}
                            href={link(`/dashboard/${role.key}`)}
                            className="rounded-lg border border-line bg-white p-6 transition-colors hover:border-blue/40"
                        >
                            <p className="text-[15px] font-semibold">{role.label}</p>
                            <p className="section-copy mt-1">
                                Open the {role.label.toLowerCase()} workspace.
                            </p>
                        </Link>
                    ))}
                </div>
            </div>
        </section>
    );
}
