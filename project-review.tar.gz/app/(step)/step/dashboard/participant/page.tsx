import { redirect } from "next/navigation";
import { headers } from "next/headers";
import Link from "next/link";
import { getStepAccessContext } from "@/lib/step/permissions";
import { isParticipant } from "@/lib/step/access-rules";
import { participantDashboard } from "@/db/queries/step/dashboards";
import { listPassportEntries, listPassportShares } from "@/db/queries/step/passports";
import { PassportShareManager } from "@/components/step/passport-share-manager";
import { levelLabel, pathwayLabel } from "@/lib/step/constants";
import { stepPath } from "@/lib/step/config";
import { stepPageMetadata } from "@/lib/step/metadata";

export async function generateMetadata() {
    return stepPageMetadata({
        path: "/dashboard/participant",
        title: "Participant Dashboard",
        description: "Your STEP enrolments, readiness and submissions.",
    });
}

export default async function ParticipantDashboardPage() {
    const headersList = await headers();
    const host = headersList.get("host") ?? "";
    const link = (p: string) => stepPath(host, p);

    const { user, context } = await getStepAccessContext();
    if (!user) redirect(`/sign-in?callbackUrl=${encodeURIComponent(link("/dashboard/participant"))}`);
    if (!isParticipant(context)) redirect(link("/dashboard"));

    const data = await participantDashboard(user.id);
    const passportStatus = data.passport?.status ?? "not_issued";
    const passportEntries = data.passport
        ? await listPassportEntries(data.passport.id)
        : [];
    const passportShares = data.passport
        ? await listPassportShares(data.passport.id)
        : [];

    return (
        <section className="container-x py-10 sm:py-14">
            <div className="mx-auto max-w-3xl">
                <header className="mb-8 flex flex-col gap-3">
                    <span className="text-[11px] font-semibold uppercase tracking-[2.4px] text-blue">
                        Participant
                    </span>
                    <h1 className="section-heading">Your STEP journey.</h1>
                </header>

                <div className="flex flex-col gap-6">
                    {data.enrolments.map(({ enrolment, assignments, pendingFeedback, overdue }) => (
                        <div key={enrolment.id} className="rounded-lg border border-line bg-white p-6">
                            <div className="flex flex-wrap items-baseline gap-x-6 gap-y-2">
                                <h2 className="text-[15px] font-semibold">
                                    {enrolment.cycle_name}
                                </h2>
                                <span className="text-[13px] text-brand-muted">
                                    {enrolment.cohort_name ?? "No cohort"} · {pathwayLabel(enrolment.pathway)}
                                </span>
                                <span className="ml-auto rounded-full bg-blue/12 px-3 py-1 text-[11px] font-semibold text-blue-dark">
                                    {levelLabel(enrolment.level)}
                                </span>
                            </div>

                            <dl className="mt-4 grid grid-cols-2 gap-4 sm:grid-cols-3">
                                <Stat label="Assignments" value={String(assignments.length)} />
                                <Stat label="Pending feedback" value={String(pendingFeedback.length)} />
                                <Stat label="Overdue" value={String(overdue.length)} />
                            </dl>

                            <div className="mt-5 flex flex-col gap-3">
                                <h3 className="text-[12px] font-semibold uppercase tracking-[1.2px] text-brand-muted">
                                    Next actions
                                </h3>
                                {assignments.length === 0 ? (
                                    <p className="section-copy">No learning assigned yet.</p>
                                ) : (
                                    assignments.slice(0, 8).map((a) => (
                                        <Link
                                            key={String(a.id)}
                                            href={link(`/dashboard/participant/assignments/${a.id}`)}
                                            className="flex items-center justify-between rounded-md border border-line bg-light/60 px-4 py-2.5 transition-colors hover:border-blue/40"
                                        >
                                            <div>
                                                <p className="text-[13px] font-semibold">{String(a.title)}</p>
                                                <p className="text-[12px] text-brand-muted">
                                                    {String(a.status)} · level {String(a.level)}
                                                </p>
                                            </div>
                                            {a.due_at ? (
                                                <span className="text-[12px] text-brand-muted">
                                                    due {new Date(Number(a.due_at) * 1000).toLocaleDateString()}
                                                </span>
                                            ) : null}
                                        </Link>
                                    ))
                                )}
                            </div>
                        </div>
                    ))}

                    <div className="rounded-lg border border-line bg-light/60 p-6">
                        <h3 className="text-[12px] font-semibold uppercase tracking-[1.2px] text-brand-muted">
                            Skills Passport
                        </h3>
                        <p className="section-copy mt-2">
                            Status: {passportStatus}
                        </p>

                        {passportEntries.length > 0 && (
                            <div className="mt-4 flex flex-col gap-2">
                                {passportEntries.map((entry) => (
                                    <div
                                        key={entry.id}
                                        className="flex items-center justify-between rounded-md border border-line bg-white px-4 py-2.5"
                                    >
                                        <div>
                                            <p className="text-[13px] font-semibold">{entry.title}</p>
                                            <p className="text-[12px] text-brand-muted">{entry.entry_type}</p>
                                        </div>
                                        <span
                                            className={`text-[11px] font-semibold ${
                                                entry.status === "verified"
                                                    ? "text-blue-dark"
                                                    : "text-destructive"
                                            }`}
                                        >
                                            {entry.status}
                                        </span>
                                    </div>
                                ))}
                            </div>
                        )}

                        {data.passport && passportStatus === "verified" && (
                            <div className="mt-5 border-t border-line pt-4">
                                <h4 className="mb-2 text-[11px] font-semibold uppercase tracking-[1.2px] text-brand-muted">
                                    Sharing
                                </h4>
                                <PassportShareManager
                                    passportId={data.passport.id}
                                    shares={passportShares}
                                />
                            </div>
                        )}
                    </div>
                </div>
            </div>
        </section>
    );
}

function Stat({ label, value }: { label: string; value: string }) {
    return (
        <div className="rounded-md border border-line bg-light/60 p-3">
            <dt className="text-[10px] font-semibold uppercase tracking-[1.2px] text-brand-muted">
                {label}
            </dt>
            <dd className="text-[15px] font-semibold">{value}</dd>
        </div>
    );
}
