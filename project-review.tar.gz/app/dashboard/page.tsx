"use client"

export default function Page() {
    return (
        <div>
            <div className="flex flex-1 flex-col gap-4 p-4 pt-0">
                <div className="grid auto-rows-min gap-4 md:grid-cols-3">
                    <div className="aspect-video rounded-xl bg-light/50" />
                    <div className="aspect-video rounded-xl bg-light/50" />
                    <div className="aspect-video rounded-xl bg-light/50" />
                </div>
                <div className="min-h-screenflex-1 rounded-xl bg-light/50 md:min-h-min" />
            </div>
        </div>
    )
}
