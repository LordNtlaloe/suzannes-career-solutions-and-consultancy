"use client";

import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { Badge } from "@/components/ui/badge";
import { useStepPath } from "@/components/step/step-path-provider";
import {
    applicationStatusLabel,
    participantGroupLabel,
    pathwayLabel,
} from "@/lib/step/constants";
import type { StepApplicationWithRelations, StepCycle } from "@/types/step";

const STATUS_VARIANT: Record<string, "default" | "secondary" | "outline" | "destructive"> = {
    draft: "outline",
    submitted: "secondary",
    under_review: "outline",
    admitted: "default",
    rejected: "destructive",
    withdrawn: "outline",
};

export function ApplicationsBrowser({
    applications,
    total,
    page,
    pageSize,
    status,
    cycleId,
    cycles,
}: {
    applications: StepApplicationWithRelations[];
    total: number;
    page: number;
    pageSize: number;
    status: string;
    cycleId: string;
    cycles: StepCycle[];
}) {
    const { path } = useStepPath();
    const router = useRouter();
    const searchParams = useSearchParams();

    const totalPages = Math.max(1, Math.ceil(total / pageSize));

    function updateQuery(next: { status?: string; cycle?: string; page?: number }) {
        const params = new URLSearchParams(searchParams.toString());
        if (next.status !== undefined) {
            if (next.status === "all") params.delete("status");
            else params.set("status", next.status);
        }
        if (next.cycle !== undefined) {
            if (next.cycle === "all") params.delete("cycle");
            else params.set("cycle", next.cycle);
        }
        if (next.page !== undefined) {
            if (next.page <= 1) params.delete("page");
            else params.set("page", String(next.page));
        }
        router.push(`${path("/admin/applications")}?${params.toString()}`);
    }

    const inputClass =
        "h-9 rounded-md border border-input bg-input/20 px-3 text-[12px] outline-none focus-visible:border-ring";

    return (
        <div className="flex flex-col gap-4">
            <div className="flex flex-wrap gap-3">
                <select
                    aria-label="Status"
                    value={status}
                    onChange={(e) => updateQuery({ status: e.target.value, page: 1 })}
                    className={inputClass}
                >
                    <option value="all">All statuses</option>
                    <option value="submitted">Submitted</option>
                    <option value="under_review">Under review</option>
                    <option value="admitted">Admitted</option>
                    <option value="rejected">Rejected</option>
                </select>
                <select
                    aria-label="Cycle"
                    value={cycleId}
                    onChange={(e) => updateQuery({ cycle: e.target.value, page: 1 })}
                    className={inputClass}
                >
                    <option value="all">All cycles</option>
                    {cycles.map((c) => (
                        <option key={c.id} value={c.id}>
                            {c.name}
                        </option>
                    ))}
                </select>
                <span className="ml-auto self-center text-[12px] text-brand-muted">
                    {total} application{total === 1 ? "" : "s"}
                </span>
            </div>

            {applications.length === 0 ? (
                <p className="rounded-lg border border-line bg-light/60 p-8 text-center section-copy">
                    No applications match these filters.
                </p>
            ) : (
                <div className="overflow-x-auto rounded-lg border border-line bg-white">
                    <table className="w-full min-w-[720px] text-left text-[13px]">
                        <thead>
                            <tr className="border-b border-line text-[11px] uppercase tracking-[1.2px] text-brand-muted">
                                <th className="px-4 py-3">Applicant</th>
                                <th className="px-4 py-3">Cohort</th>
                                <th className="px-4 py-3">Pathway</th>
                                <th className="px-4 py-3">Status</th>
                                <th className="px-4 py-3 text-right">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            {applications.map((app) => (
                                <tr key={app.id} className="border-b border-line last:border-0">
                                    <td className="px-4 py-3">
                                        <p className="font-semibold">{app.applicant_name ?? "—"}</p>
                                        <p className="text-[12px] text-brand-muted">{app.applicant_email ?? ""}</p>
                                    </td>
                                    <td className="px-4 py-3">{app.cohort_name ?? "No preference"}</td>
                                    <td className="px-4 py-3">
                                        {pathwayLabel(app.pathway)}
                                        <span className="block text-[11px] text-brand-muted">
                                            {participantGroupLabel(app.participant_group)}
                                        </span>
                                    </td>
                                    <td className="px-4 py-3">
                                        <Badge variant={STATUS_VARIANT[app.status] ?? "secondary"}>
                                            {applicationStatusLabel(app.status)}
                                        </Badge>
                                    </td>
                                    <td className="px-4 py-3 text-right">
                                        <Link
                                            href={path(`/admin/applications/${app.id}`)}
                                            className="font-semibold text-blue-dark transition-opacity hover:opacity-70"
                                        >
                                            Review →
                                        </Link>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            )}

            <div className="flex items-center justify-between text-[12px]">
                <button
                    type="button"
                    disabled={page <= 1}
                    onClick={() => updateQuery({ page: page - 1 })}
                    className="rounded-md border border-line px-3 py-1.5 font-semibold text-brand disabled:opacity-40"
                >
                    Previous
                </button>
                <span className="text-brand-muted">
                    Page {page} of {totalPages}
                </span>
                <button
                    type="button"
                    disabled={page >= totalPages}
                    onClick={() => updateQuery({ page: page + 1 })}
                    className="rounded-md border border-line px-3 py-1.5 font-semibold text-brand disabled:opacity-40"
                >
                    Next
                </button>
            </div>
        </div>
    );
}
