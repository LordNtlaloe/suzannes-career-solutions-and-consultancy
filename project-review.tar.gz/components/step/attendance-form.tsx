"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { toast } from "sonner";
import { recordAttendanceAction } from "@/actions/step/mentoring.actions";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";

type AttendanceRow = {
    enrolment_id: string;
    participant_name: string;
    cycle_name?: string | null;
    cohort_name?: string | null;
    attendance_id?: string | null;
    attended?: number | null;
    feedback?: string | null;
};

export function AttendanceForm({
    sessionId,
    rows,
}: {
    sessionId: string;
    rows: AttendanceRow[];
}) {
    const router = useRouter();
    const [pending, startTransition] = useTransition();
    const [error, setError] = useState<string | null>(null);
    const [state, setState] = useState<Record<string, { attended: boolean; feedback: string }>>(
        () =>
            Object.fromEntries(
                rows.map((r) => [
                    String(r.enrolment_id),
                    { attended: r.attended === 1, feedback: r.feedback ?? "" },
                ]),
            ),
    );

    function setRow(enrolmentId: string, patch: Partial<{ attended: boolean; feedback: string }>) {
        setState((prev) => ({
            ...prev,
            [enrolmentId]: { ...(prev[enrolmentId] ?? { attended: false, feedback: "" }), ...patch },
        }));
    }

    function submit(enrolmentId: string) {
        const row = state[enrolmentId];
        if (!row) return;
        setError(null);
        startTransition(async () => {
            try {
                await recordAttendanceAction({
                    sessionId,
                    enrolmentId,
                    attended: row.attended,
                    feedback: row.feedback || undefined,
                });
                toast.success("Attendance recorded");
                router.refresh();
            } catch (err) {
                setError(err instanceof Error ? err.message : "Something went wrong");
            }
        });
    }

    if (rows.length === 0) {
        return <p className="section-copy">No assigned participants for this session.</p>;
    }

    return (
        <div className="flex flex-col gap-3">
            {error && (
                <p className="rounded-md border border-destructive/40 bg-destructive/10 px-2 py-1.5 text-[11px] text-destructive">
                    {error}
                </p>
            )}

            {rows.map((r) => {
                const id = String(r.enrolment_id);
                const row = state[id];
                return (
                    <div
                        key={id}
                        className="flex flex-col gap-3 rounded-md border border-line bg-white p-4"
                    >
                        <div className="flex flex-wrap items-center gap-x-3 gap-y-1">
                            <p className="text-[14px] font-semibold">{String(r.participant_name)}</p>
                            <span className="text-[12px] text-brand-muted">
                                {String(r.cycle_name ?? "—")} · {String(r.cohort_name ?? "No cohort")}
                            </span>
                        </div>

                        <div className="flex items-center gap-2">
                            <Label className="text-[11px] font-semibold">Attended</Label>
                            <input
                                type="checkbox"
                                checked={row.attended}
                                onChange={(e) => setRow(id, { attended: e.target.checked })}
                                className="size-4 accent-blue"
                            />
                        </div>

                        <Textarea
                            rows={2}
                            value={row.feedback}
                            onChange={(e) => setRow(id, { feedback: e.target.value })}
                            placeholder="Session feedback (optional)"
                            className="rounded-md border border-input bg-input/20 px-2 py-1.5 text-[12px] outline-none"
                        />

                        <Button
                            type="button"
                            size="sm"
                            className="self-end"
                            disabled={pending}
                            onClick={() => submit(id)}
                        >
                            Save
                        </Button>
                    </div>
                );
            })}
        </div>
    );
}
