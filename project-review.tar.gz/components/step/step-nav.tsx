"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { GraduationCap, LogOut } from "lucide-react";
import { useStepPath } from "@/components/step/step-path-provider";
import { authClient } from "@/lib/auth-client";
import { toast } from "sonner";

type StepNavProps = {
    signedIn: boolean;
    isStaff: boolean;
    isParticipant: boolean;
    hasAccess?: boolean;
};

export function StepNav({ signedIn, isStaff, isParticipant, hasAccess }: StepNavProps) {
    const { path } = useStepPath();
    const router = useRouter();

    const links = [
        { href: path("/"), label: "Home" },
        { href: path("/apply"), label: "Apply" },
    ];

    if (isParticipant || hasAccess) {
        links.push({ href: path("/dashboard"), label: "Dashboard" });
    }

    const handleSignOut = async () => {
        await authClient.signOut(
            {},
            {
                onSuccess: () => {
                    router.push(path("/"));
                    router.refresh();
                },
                onError: (ctx) => {
                    toast.error(ctx.error.message ?? "Could not sign out");
                },
            },
        );
    };

    return (
        <header className="bg-hero-grad text-white">
            <div className="container-x flex h-18 items-center gap-8">
                <Link
                    href={path("/")}
                    className="flex items-center gap-2 text-[15px] font-semibold"
                >
                    <GraduationCap className="size-5 text-blue-light" />
                    STEP
                </Link>

                <nav className="ml-auto hidden items-center gap-7 text-[12px] text-[#c4c4c4] sm:flex">
                    {links.map((link) => (
                        <Link
                            key={link.href}
                            href={link.href}
                            className="transition-colors hover:text-white"
                        >
                            {link.label}
                        </Link>
                    ))}
                </nav>

                <div className="ml-auto flex items-center gap-3 sm:ml-0">
                    {signedIn ? (
                        <>
                            {isStaff && (
                                <Link
                                    href={path("/admin")}
                                    className="rounded-md border border-white/20 px-3 py-1.5 text-[11px] font-semibold text-[#c4c4c4] transition-colors hover:border-white/40 hover:text-white"
                                >
                                    Admin
                                </Link>
                            )}
                            <button
                                type="button"
                                onClick={handleSignOut}
                                className="inline-flex items-center gap-1.5 rounded-md border border-white/20 px-3 py-1.5 text-[11px] font-semibold text-[#c4c4c4] transition-colors hover:border-white/40 hover:text-white"
                            >
                                <LogOut className="size-3.5" />
                                Sign out
                            </button>
                        </>
                    ) : (
                        <Link
                            href="/sign-in"
                            className="btn-brand min-h-9! px-5! text-[11px]!"
                        >
                            Sign in
                        </Link>
                    )}
                </div>
            </div>
        </header>
    );
}
