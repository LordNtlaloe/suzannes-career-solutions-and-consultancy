// db/queries/step/applications.ts
import "server-only";

import { database as db } from "@/db/database";
import type {
    StepApplication,
    StepApplicationWithRelations,
} from "@/types/step";

const RELATIONS = `
    u.name  AS applicant_name,
    u.email AS applicant_email,
    c.name  AS cohort_name
`;

export async function getApplicationById(id: string): Promise<StepApplication | null> {
    const result = await db.execute({
        sql: `SELECT * FROM step_applications WHERE id = ?`,
        args: [id],
    });
    return (result.rows[0] as unknown as StepApplication | undefined) ?? null;
}

export async function getLatestApplicationByUser(userId: string): Promise<StepApplication | null> {
    const result = await db.execute({
        sql: `SELECT * FROM step_applications WHERE user_id = ? ORDER BY created_at DESC LIMIT 1`,
        args: [userId],
    });
    return (result.rows[0] as unknown as StepApplication | undefined) ?? null;
}

export type CreateApplicationInput = {
    id: string;
    userId: string;
    cycleId: string;
    cohortId: string | null;
    pathway: string;
    participantGroup: string;
    goals: string | null;
    baseline: string | null;
    consentContact: boolean;
    consentData: boolean;
    consentProgramme: boolean;
    status: "draft" | "submitted";
};

export async function createApplication(input: CreateApplicationInput): Promise<void> {
    await db.execute({
        sql: `
            INSERT INTO step_applications (
                id, user_id, cycle_id, cohort_id, pathway, participant_group,
                goals, baseline, consent_contact, consent_data, consent_programme,
                status, submitted_at, created_at, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, unixepoch(), unixepoch())
        `,
        args: [
            input.id,
            input.userId,
            input.cycleId,
            input.cohortId,
            input.pathway,
            input.participantGroup,
            input.goals,
            input.baseline,
            input.consentContact ? 1 : 0,
            input.consentData ? 1 : 0,
            input.consentProgramme ? 1 : 0,
            input.status,
            input.status === "submitted" ? Math.floor(Date.now() / 1000) : null,
        ],
    });
}

export async function updateApplicationDraft(
    id: string,
    input: {
        cohortId: string | null;
        pathway: string;
        participantGroup: string;
        goals: string | null;
        baseline: string | null;
    },
): Promise<void> {
    await db.execute({
        sql: `
            UPDATE step_applications
            SET cohort_id = ?, pathway = ?, participant_group = ?,
                goals = ?, baseline = ?, updated_at = unixepoch()
            WHERE id = ? AND status = 'draft'
        `,
        args: [input.cohortId, input.pathway, input.participantGroup, input.goals, input.baseline, id],
    });
}

export async function submitApplication(
    id: string,
    input: {
        consentContact: boolean;
        consentData: boolean;
        consentProgramme: boolean;
    },
): Promise<void> {
    await db.execute({
        sql: `
            UPDATE step_applications
            SET consent_contact = ?, consent_data = ?, consent_programme = ?,
                status = 'submitted', submitted_at = unixepoch(), updated_at = unixepoch()
            WHERE id = ? AND status = 'draft'
        `,
        args: [input.consentContact ? 1 : 0, input.consentData ? 1 : 0, input.consentProgramme ? 1 : 0, id],
    });
}

export async function getLatestNoticeVersion(
    userId: string,
    scope: string,
): Promise<number> {
    const result = await db.execute({
        sql: `SELECT COALESCE(MAX(notice_version), 0) AS v FROM step_consents WHERE user_id = ? AND scope = ?`,
        args: [userId, scope],
    });
    return Number(result.rows[0]?.v ?? 0);
}

export async function recordConsent(input: {
    id: string;
    userId: string;
    scope: string;
    noticeVersion: number;
    action: "grant" | "withdraw";
    recordedBy: string | null;
}): Promise<void> {
    await db.execute({
        sql: `
            INSERT INTO step_consents (id, user_id, scope, notice_version, action, recorded_by, recorded_at)
            VALUES (?, ?, ?, ?, ?, ?, unixepoch())
        `,
        args: [input.id, input.userId, input.scope, input.noticeVersion, input.action, input.recordedBy],
    });
}

export async function updateApplicationStatus(
    id: string,
    input: {
        status: string;
        reviewedBy: string | null;
        reviewNote: string | null;
        feedback?: string | null;
    },
): Promise<void> {
    await db.execute({
        sql: `
            UPDATE step_applications
            SET status = ?, reviewed_by = ?, review_note = ?, feedback = ?,
                reviewed_at = unixepoch(), updated_at = unixepoch()
            WHERE id = ?
        `,
        args: [input.status, input.reviewedBy, input.reviewNote, input.feedback ?? null, id],
    });
}

export async function getApplicationForReview(id: string) {
    const result = await db.execute({
        sql: `
            SELECT a.*, u.name AS applicant_name, u.email AS applicant_email, c.name AS cohort_name
            FROM step_applications a
            LEFT JOIN user u ON u.id = a.user_id
            LEFT JOIN step_cohorts c ON c.id = a.cohort_id
            WHERE a.id = ?
        `,
        args: [id],
    });
    return (result.rows[0] as unknown as Record<string, unknown> | undefined) ?? null;
}

export type ApplicationReviewScope = {
    status?: string;
    cycleId?: string | null;
    cohortId?: string | null;
    limit: number;
    offset: number;
};

/** Applications within a reviewer's cycle/cohort scope (paginated). */
export async function listApplicationsForReview(
    scope: ApplicationReviewScope,
): Promise<StepApplicationWithRelations[]> {
    const conditions: string[] = [];
    const args: (string | number)[] = [];

    if (scope.status) {
        conditions.push("a.status = ?");
        args.push(scope.status);
    }
    if (scope.cycleId) {
        conditions.push("a.cycle_id = ?");
        args.push(scope.cycleId);
    }
    if (scope.cohortId) {
        conditions.push("a.cohort_id = ?");
        args.push(scope.cohortId);
    }

    const where = conditions.length ? `WHERE ${conditions.join(" AND ")}` : "";

    const result = await db.execute({
        sql: `
            SELECT a.*, ${RELATIONS}
            FROM step_applications a
            LEFT JOIN user u ON u.id = a.user_id
            LEFT JOIN step_cohorts c ON c.id = a.cohort_id
            ${where}
            ORDER BY a.created_at DESC
            LIMIT ? OFFSET ?
        `,
        args: [...args, scope.limit, scope.offset],
    });
    return result.rows as unknown as StepApplicationWithRelations[];
}

export async function countApplicationsForReview(
    scope: Omit<ApplicationReviewScope, "limit" | "offset">,
): Promise<number> {
    const conditions: string[] = [];
    const args: (string | number)[] = [];
    if (scope.status) {
        conditions.push("a.status = ?");
        args.push(scope.status);
    }
    if (scope.cycleId) {
        conditions.push("a.cycle_id = ?");
        args.push(scope.cycleId);
    }
    if (scope.cohortId) {
        conditions.push("a.cohort_id = ?");
        args.push(scope.cohortId);
    }
    const where = conditions.length ? `WHERE ${conditions.join(" AND ")}` : "";
    const result = await db.execute({
        sql: `SELECT COUNT(*) AS c FROM step_applications a ${where}`,
        args,
    });
    return Number(result.rows[0]?.c ?? 0);
}
