// db/queries/step/dashboards.ts
//
// Role-specific dashboard queries. Each returns only the data the view needs,
// scoped to the caller's authorisations (the caller resolves access first and
// passes explicit ids — no free-form user-supplied scoping).
import "server-only";

import { database as db } from "@/db/database";
import { getEnrolmentsByUserId, getParticipantIdentity } from "@/db/queries/step/access";
import { getLatestPassport, listPassportEntries } from "@/db/queries/step/passports";
import { listEnrolmentAssignments } from "@/db/queries/step/learning";
import { listEvidenceForEnrolment } from "@/db/queries/step/evidence";
import {
    listAssignedEnrolments,
    listDevelopmentActionsForMentor,
    listMentoringSessions,
} from "@/db/queries/step/mentoring";
import { listCycles } from "@/db/queries/step/cycles";
import { listProgressionDecisions } from "@/db/queries/step/progression";

export async function participantDashboard(userId: string) {
    const participant = await getParticipantIdentity(userId);
    if (!participant) return { participant: null, enrolments: [] };

    const enrolments = await getEnrolmentsByUserId(userId);
    const passport = await getLatestPassport(participant.id);

    const detailed = await Promise.all(
        enrolments.map(async (enrolment) => {
            const [assignments, evidence] = await Promise.all([
                listEnrolmentAssignments(enrolment.id),
                listEvidenceForEnrolment(enrolment.id),
            ]);
            const pendingFeedback = evidence.filter((e) => e.status === "submitted");
            const overdue = assignments.filter(
                (a) =>
                    a.status !== "completed" &&
                    a.status !== "waived" &&
                    a.due_at &&
                    Number(a.due_at) < Math.floor(Date.now() / 1000),
            );
            return { enrolment, assignments, pendingFeedback, overdue };
        }),
    );

    return { participant, enrolments: detailed, passport };
}

export async function staffDashboard(scope: { cycleId?: string | null; cohortId?: string | null }) {
    const conditions: string[] = [];
    const args: (string | number)[] = [];

    if (scope.cycleId) {
        conditions.push("a.cycle_id = ?");
        args.push(scope.cycleId);
    }

    const applications = await db.execute({
        sql: `
            SELECT COUNT(*) AS c FROM step_applications a
            ${conditions.length ? `WHERE ${conditions.join(" AND ")} AND a.status IN ('submitted','under_review')` : "WHERE a.status IN ('submitted','under_review')"}
        `,
        args,
    });

    const evidenceConditions: string[] = ["ev.status = 'submitted'"];
    const evidenceArgs: (string | number)[] = [];
    if (scope.cycleId) {
        evidenceConditions.push("e.cycle_id = ?");
        evidenceArgs.push(scope.cycleId);
    }
    const evidence = await db.execute({
        sql: `
            SELECT COUNT(*) AS c
            FROM step_evidence ev
            LEFT JOIN step_learning_assignments la ON la.id = ev.assignment_id
            LEFT JOIN step_enrolments e ON e.id = la.enrolment_id
            WHERE ${evidenceConditions.join(" AND ")}
        `,
        args: evidenceArgs,
    });

    const overdue = await db.execute({
        sql: `
            SELECT COUNT(*) AS c
            FROM step_learning_assignments la
            JOIN step_enrolments e ON e.id = la.enrolment_id
            WHERE la.status IN ('assigned','in_progress')
              AND la.due_at IS NOT NULL AND la.due_at < unixepoch()
              ${scope.cycleId ? "AND e.cycle_id = ?" : ""}
        `,
        args: scope.cycleId ? [scope.cycleId] : [],
    });

    const candidates = await db.execute({
        sql: `
            SELECT COUNT(*) AS c
            FROM step_enrolments e
            WHERE e.status = 'enrolled'
              AND e.level != 'graduate'
              ${scope.cycleId ? "AND e.cycle_id = ?" : ""}
        `,
        args: scope.cycleId ? [scope.cycleId] : [],
    });

    return {
        applicationQueue: Number(applications.rows[0]?.c ?? 0),
        evidenceQueue: Number(evidence.rows[0]?.c ?? 0),
        overdueAssignments: Number(overdue.rows[0]?.c ?? 0),
        progressionCandidates: Number(candidates.rows[0]?.c ?? 0),
    };
}

export async function mentorDashboard(mentorUserId: string) {
    const [assigned, sessions, actions] = await Promise.all([
        listAssignedEnrolments(mentorUserId),
        listMentoringSessions(mentorUserId),
        listDevelopmentActionsForMentor(mentorUserId),
    ]);
    return { assigned, sessions, actions };
}

export async function adminDashboard() {
    const cycles = await listCycles();
    const staff = await db.execute({
        sql: `
            SELECT sa.*, u.name AS staff_name
            FROM step_staff_assignments sa
            LEFT JOIN user u ON u.id = sa.user_id
            WHERE sa.active = TRUE
            ORDER BY sa.role ASC
        `,
        args: [],
    });
    const totals = await db.execute({
        sql: `
            SELECT
                (SELECT COUNT(*) FROM step_participants) AS participants,
                (SELECT COUNT(*) FROM step_enrolments WHERE status = 'enrolled') AS active_enrolments,
                (SELECT COUNT(*) FROM step_applications WHERE status = 'admitted') AS admitted,
                (SELECT COUNT(*) FROM step_passports WHERE status = 'verified') AS verified_passports
        `,
        args: [],
    });
    return {
        cycles,
        staff: staff.rows as unknown as Record<string, unknown>[],
        totals: totals.rows[0] as unknown as Record<string, unknown>,
    };
}

export async function progressionHistoryForEnrolment(enrolmentId: string) {
    const enrolment = await db.execute({
        sql: `SELECT participant_id FROM step_enrolments WHERE id = ?`,
        args: [enrolmentId],
    });
    const participantId = (enrolment.rows[0] as { participant_id?: string } | undefined)
        ?.participant_id;
    if (!participantId) return [];
    return listProgressionDecisions(participantId);
}

export async function passportForParticipant(participantId: string) {
    const passport = await getLatestPassport(participantId);
    const entries = passport ? await listPassportEntries(passport.id) : [];
    return { passport, entries };
}
