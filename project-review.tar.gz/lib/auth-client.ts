// ./lib/client.ts
import { createAuthClient } from "better-auth/react";
import { adminClient } from "better-auth/client/plugins";

export const authClient = createAuthClient({
    baseURL: process.env.NEXT_PUBLIC_APP_URL || "http://localhost:3000",
    plugins: [adminClient()],
});

export type Session = typeof authClient.$Infer.Session
export const { signIn, signUp, signOut, useSession, changePassword, resetPassword, requestPasswordReset } = authClient;